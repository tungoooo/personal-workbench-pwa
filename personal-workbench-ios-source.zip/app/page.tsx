"use client";

import { useEffect, useMemo, useRef, useState } from "react";

type Tab = "总览" | "记账" | "运动" | "待办" | "同步";
type Transaction = { id: number; type: "支出" | "收入"; category: string; amount: number; time: string; createdAt?: string; merchant?: string; platform?: string };
type Task = { id: number; title: string; category: string; deadline: string; deadlineISO?: string; done: boolean; priority?: string };
type SetRecord = { reps: number; weight: number };
type Exercise = { id: string; name: string; sets: number; reps: number | null; weight: number | null; group: string };
type WorkoutSession = { id: string; date: string; time: string; title: string; duration: number; volume: number; exercises: { name: string; sets: SetRecord[] }[] };
type TrainingPlan = { id: string; name: string; days: string; actions: string[] };

const nav: { label: Tab; mark: string }[] = [
  { label: "总览", mark: "⌂" }, { label: "记账", mark: "¥" }, { label: "运动", mark: "动" }, { label: "待办", mark: "✓" }, { label: "同步", mark: "↻" },
];
const initialExercises: Exercise[] = [];
const actionLibrary: Exercise[] = [];
const workoutSessions: WorkoutSession[] = [];
const initialTransactions: Transaction[] = [];
const initialTasks: Task[] = [];
const initialPlans: TrainingPlan[] = [];

function suggestCategory(text: string) {
  if (/美团|饿了么|餐|饭|咖啡|茶|麦当劳|肯德基|超市食品/.test(text)) return "餐饮";
  if (/地铁|公交|打车|滴滴|铁路|机票|加油|停车/.test(text)) return "交通";
  if (/淘宝|京东|拼多多|商场|超市|便利店|抖音商城/.test(text)) return "购物";
  if (/电影|游戏|会员|娱乐|视频|音乐/.test(text)) return "娱乐";
  return "其他";
}

function parsePaymentText(raw: string) {
  const decoded = raw.replace(/\+/g, " ");
  const currency = [...decoded.matchAll(/[¥￥]\s*(\d+(?:\.\d{1,2})?)/g)].map((match) => Number(match[1]));
  const labeled = decoded.match(/(?:实付|付款|支付|金额|收款)[^\d]{0,10}(\d+(?:\.\d{1,2})?)/);
  const amount = currency.find((value) => value > 0) || Number(labeled?.[1] || 0);
  const platform = /微信|WeChat/i.test(decoded) ? "微信支付" : /支付宝|Alipay/i.test(decoded) ? "支付宝" : /抖音/.test(decoded) ? "抖音支付" : /美团/.test(decoded) ? "美团支付" : "其他支付";
  const lines = decoded.split(/\n|\r/).map((line) => line.trim()).filter((line) => line.length > 1 && line.length < 30 && !/[¥￥]\s*\d/.test(line) && !/支付成功|付款成功|交易成功|收款成功/.test(line));
  const merchant = lines.find((line) => !/微信支付|支付宝|抖音支付|美团支付|交易时间|订单/.test(line)) || "自动识别商户";
  return { amount, platform, merchant, category: suggestCategory(decoded) };
}

export default function Home() {
  const [active, setActive] = useState<Tab>("总览");
  const [transactions, setTransactions] = useState(initialTransactions);
  const [tasks, setTasks] = useState(initialTasks);
  const [transactionOpen, setTransactionOpen] = useState(false);
  const [taskOpen, setTaskOpen] = useState(false);
  const [amount, setAmount] = useState("");
  const [transactionType, setTransactionType] = useState<"支出" | "收入">("支出");
  const [category, setCategory] = useState("餐饮");
  const [merchant, setMerchant] = useState("");
  const [paymentPlatform, setPaymentPlatform] = useState("微信支付");
  const [bankAccounts, setBankAccounts] = useState<string[]>([]);
  const [selectedBankAccount, setSelectedBankAccount] = useState("");
  const [newBankAccount, setNewBankAccount] = useState("");
  const [incomeCategories, setIncomeCategories] = useState<string[]>(["正常收入", "额外收入"]);
  const [newIncomeCategory, setNewIncomeCategory] = useState("");
  const [shortcutOpen, setShortcutOpen] = useState(false);
  const [shortcutUrl, setShortcutUrl] = useState("https://tungoooo.github.io/personal-workbench-pwa/#quick-pay?raw=");
  const [taskTitle, setTaskTitle] = useState("");
  const [taskCategory, setTaskCategory] = useState("日常");
  const [deadline, setDeadline] = useState("");
  const [taskPriority, setTaskPriority] = useState("无");
  const [editingTaskId, setEditingTaskId] = useState<number | null>(null);
  const [taskFilter, setTaskFilter] = useState("全部");
  const [backup, setBackup] = useState(true);
  const [syncing, setSyncing] = useState(false);
  const [toast, setToast] = useState("");
  const [hydrated, setHydrated] = useState(false);
  const [workoutMode, setWorkoutMode] = useState<"plan" | "active" | "confirm" | "decision" | "chooseAction" | "sessionDone">("plan");
  const [workoutExercises, setWorkoutExercises] = useState<Exercise[]>(initialExercises);
  const [exerciseLibrary, setExerciseLibrary] = useState<Exercise[]>(actionLibrary);
  const [trainingPlans, setTrainingPlans] = useState<TrainingPlan[]>(initialPlans);
  const [workoutHistory, setWorkoutHistory] = useState<WorkoutSession[]>(workoutSessions);
  const [activePlanName, setActivePlanName] = useState("");
  const [workoutStartedAt, setWorkoutStartedAt] = useState<number | null>(null);
  const [exerciseIndex, setExerciseIndex] = useState(0);
  const [records, setRecords] = useState<SetRecord[][]>([]);
  const [actualReps, setActualReps] = useState(8);
  const [actualWeight, setActualWeight] = useState(60);
  const [customOpen, setCustomOpen] = useState(false);
  const [customName, setCustomName] = useState("");
  const [customSets, setCustomSets] = useState("4");
  const [customReps, setCustomReps] = useState("");
  const [customWeight, setCustomWeight] = useState("");

  useEffect(() => {
    try {
      const resetKey = "personal-workbench-clean-v1";
      if (!localStorage.getItem(resetKey)) {
        localStorage.removeItem("personal-workbench-prototype");
        localStorage.removeItem("personal-workbench-backups");
        localStorage.setItem(resetKey, "done");
      } else {
        const saved = localStorage.getItem("personal-workbench-prototype");
        if (saved) {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed.transactions)) setTransactions(parsed.transactions);
          if (Array.isArray(parsed.tasks)) setTasks(parsed.tasks);
          if (Array.isArray(parsed.exerciseLibrary)) setExerciseLibrary(parsed.exerciseLibrary);
          if (Array.isArray(parsed.trainingPlans)) setTrainingPlans(parsed.trainingPlans);
          if (Array.isArray(parsed.workoutHistory)) setWorkoutHistory(parsed.workoutHistory);
          if (Array.isArray(parsed.bankAccounts)) setBankAccounts(parsed.bankAccounts);
          if (Array.isArray(parsed.incomeCategories) && parsed.incomeCategories.length) setIncomeCategories(parsed.incomeCategories);
          if (typeof parsed.backup === "boolean") setBackup(parsed.backup);
        }
      }
    } catch { /* Safely starts with empty local data. */ }
    setHydrated(true);
  }, []);
  useEffect(() => {
    if (hydrated) localStorage.setItem("personal-workbench-prototype", JSON.stringify({ transactions, tasks, backup, exerciseLibrary, trainingPlans, workoutHistory, bankAccounts, incomeCategories }));
  }, [transactions, tasks, backup, exerciseLibrary, trainingPlans, workoutHistory, bankAccounts, incomeCategories, hydrated]);
  useEffect(() => {
    if (!hydrated) return;
    if (!transactions.length && !tasks.length && !exerciseLibrary.length && !trainingPlans.length && !workoutHistory.length && !bankAccounts.length && incomeCategories.join("|") === "正常收入|额外收入") return;
    const snapshot = { createdAt: new Date().toISOString(), transactions, tasks, backup, exerciseLibrary, trainingPlans, workoutHistory, bankAccounts, incomeCategories };
    try {
      const previous = JSON.parse(localStorage.getItem("personal-workbench-backups") || "[]");
      const last = previous[0];
      const signature = JSON.stringify({ transactions, tasks, backup, exerciseLibrary, trainingPlans, workoutHistory, bankAccounts, incomeCategories });
      if (!last || last.signature !== signature) localStorage.setItem("personal-workbench-backups", JSON.stringify([{ ...snapshot, signature }, ...previous].slice(0, 5)));
    } catch { /* Local backup creation is best-effort. */ }
  }, [transactions, tasks, backup, exerciseLibrary, trainingPlans, workoutHistory, bankAccounts, incomeCategories, hydrated]);
  useEffect(() => {
    if (!hydrated) return;
    setShortcutUrl(window.location.protocol === "capacitor:"
      ? "workbench://quick-pay?raw="
      : `${window.location.origin}${window.location.pathname}#quick-pay?raw=`);
    const handleRoute = () => {
      const hash = window.location.hash;
      if (hash.startsWith("#workout")) { setActive("运动"); return; }
      if (!hash.startsWith("#quick-pay")) return;
      const query = hash.includes("?") ? hash.slice(hash.indexOf("?") + 1) : "";
      const params = new URLSearchParams(query);
      const raw = params.get("raw");
      if (raw) {
        const parsed = parsePaymentText(raw);
        if (parsed.amount) setAmount(parsed.amount.toFixed(2));
        setMerchant(parsed.merchant); setPaymentPlatform(parsed.platform); setCategory(parsed.category);
      }
      setTransactionType("支出"); setActive("记账"); setTransactionOpen(true);
      history.replaceState(null, "", `${location.pathname}${location.search}`);
    };
    handleRoute();
    window.addEventListener("hashchange", handleRoute);
    return () => window.removeEventListener("hashchange", handleRoute);
  }, [hydrated]);

  const spentToday = useMemo(() => transactions.filter((t) => t.type === "支出" && t.time.includes("今天")).reduce((sum, t) => sum + t.amount, 0), [transactions]);
  const pendingTasks = tasks.filter((task) => !task.done).length;
  const filteredTasks = tasks.filter((task) => taskFilter === "全部" || task.category === taskFilter);
  const currentExercise = workoutExercises[exerciseIndex];

  function notify(message: string) {
    setToast(message);
    window.setTimeout(() => setToast(""), 2200);
  }
  function addTransaction() {
    const value = Number(amount);
    if (!value || value <= 0) return;
    if (transactionType === "收入" && !category.trim()) { notify("请选择收入分类"); return; }
    if (transactionType === "收入" && paymentPlatform === "银行卡" && !selectedBankAccount.trim()) { notify("请先添加并选择银行卡"); return; }
    const savedPlatform = transactionType === "收入" && paymentPlatform === "银行卡" && selectedBankAccount ? `银行卡 · ${selectedBankAccount}` : paymentPlatform;
    setTransactions((items) => [{ id: Date.now(), type: transactionType, category, amount: value, time: "今天 刚刚", createdAt: new Date().toISOString(), merchant: transactionType === "支出" ? merchant.trim() || undefined : undefined, platform: savedPlatform }, ...items]);
    setTransactionOpen(false); setMerchant(""); setAmount(""); notify("已记录一笔，并创建本地备份");
  }
  function addBankAccount() { const name = newBankAccount.trim(); if (!name || bankAccounts.includes(name)) return; setBankAccounts((items) => [...items, name]); setSelectedBankAccount(name); setNewBankAccount(""); }
  function renameBankAccount(index: number, name: string) { const oldName = bankAccounts[index]; setBankAccounts((items) => items.map((item, itemIndex) => itemIndex === index ? name : item)); if (selectedBankAccount === oldName) setSelectedBankAccount(name); }
  function deleteBankAccount(index: number) { const removed = bankAccounts[index]; setBankAccounts((items) => items.filter((_, itemIndex) => itemIndex !== index)); if (selectedBankAccount === removed) setSelectedBankAccount(""); }
  function addIncomeCategory() { const name = newIncomeCategory.trim(); if (!name || incomeCategories.includes(name)) return; setIncomeCategories((items) => [...items, name]); setCategory(name); setNewIncomeCategory(""); }
  function renameIncomeCategory(index: number, name: string) { const oldName = incomeCategories[index]; setIncomeCategories((items) => items.map((item, itemIndex) => itemIndex === index ? name : item)); if (category === oldName) setCategory(name); }
  function deleteIncomeCategory(index: number) { if (incomeCategories.length === 1) return; const removed = incomeCategories[index]; const next = incomeCategories.filter((_, itemIndex) => itemIndex !== index); setIncomeCategories(next); if (category === removed) setCategory(next[0]); }
  function saveTask() {
    if (!taskTitle.trim() || !deadline) return;
    const date = new Date(deadline);
    const next = { title: taskTitle.trim(), category: taskCategory, deadline: `${date.getMonth() + 1}月${date.getDate()}日 ${String(date.getHours()).padStart(2, "0")}:${String(date.getMinutes()).padStart(2, "0")}`, deadlineISO: deadline, priority: taskPriority === "无" ? undefined : taskPriority };
    if (editingTaskId !== null) setTasks((items) => items.map((item) => item.id === editingTaskId ? { ...item, ...next } : item));
    else setTasks((items) => [{ id: Date.now(), ...next, done: false }, ...items]);
    setTaskTitle(""); setTaskPriority("无"); setEditingTaskId(null); setTaskOpen(false); notify(editingTaskId !== null ? "待办已修改" : "待办已创建");
  }
  function openNewTask() { setEditingTaskId(null); setTaskTitle(""); setTaskCategory("日常"); setTaskPriority("无"); setDeadline(""); setTaskOpen(true); }
  function editTask(task: Task) { setEditingTaskId(task.id); setTaskTitle(task.title); setTaskCategory(task.category); setTaskPriority(task.priority || "无"); setDeadline(task.deadlineISO || ""); setTaskOpen(true); }
  function openSetConfirmation() {
    setActualReps(currentExercise.reps ?? 0); setActualWeight(currentExercise.weight ?? 0); setWorkoutMode("confirm");
  }
  function saveSet() {
    const next = records.map((group) => [...group]);
    next[exerciseIndex].push({ reps: actualReps, weight: actualWeight });
    setRecords(next);
    setWorkoutMode("decision");
    notify(`第 ${next[exerciseIndex].length} 组已保存`);
  }
  function chooseExercise(index: number) {
    setExerciseIndex(index); setActualReps(workoutExercises[index].reps ?? 0); setActualWeight(workoutExercises[index].weight ?? 0); setWorkoutMode("active");
  }
  function addLibraryExercise(exercise: Exercise) {
    const existing = workoutExercises.findIndex((item) => item.id === exercise.id);
    if (existing >= 0) { chooseExercise(existing); return; }
    const nextExercises = [...workoutExercises, exercise];
    setWorkoutExercises(nextExercises); setRecords((items) => [...items, []]); setExerciseIndex(nextExercises.length - 1); setActualReps(exercise.reps ?? 0); setActualWeight(exercise.weight ?? 0); setWorkoutMode("active"); notify(`${exercise.name}已加入本次训练`);
  }
  function addCustomExercise() {
    if (!customName.trim()) return;
    const exercise: Exercise = { id: `custom-${Date.now()}`, name: customName.trim(), sets: Math.max(1, Number(customSets) || 1), reps: customReps === "" ? null : Number(customReps), weight: customWeight === "" ? null : Number(customWeight), group: "自定义" };
    const nextExercises = [...workoutExercises, exercise];
    setWorkoutExercises(nextExercises); setRecords((items) => [...items, []]); setExerciseIndex(nextExercises.length - 1); setActualReps(exercise.reps ?? 0); setActualWeight(exercise.weight ?? 0); setCustomOpen(false); setCustomName(""); setWorkoutMode("active"); notify(`${exercise.name}已加入本次训练`);
  }
  function startWorkout(plan?: TrainingPlan) {
    const selectedPlan = plan || trainingPlans[0];
    if (!selectedPlan) { notify("请先制定训练计划"); return; }
    const planned = selectedPlan.actions.map((name) => exerciseLibrary.find((item) => item.name === name)).filter((item): item is Exercise => Boolean(item));
    if (!planned.length) { notify("计划中还没有可用动作"); return; }
    setWorkoutExercises(planned); setRecords(planned.map(() => [])); setExerciseIndex(0); setActualReps(planned[0].reps ?? 0); setActualWeight(planned[0].weight ?? 0); setActivePlanName(selectedPlan.name); setWorkoutStartedAt(Date.now()); setWorkoutMode("active");
  }
  function finishWorkout() {
    const now = new Date(); const completed = workoutExercises.map((exercise, index) => ({ name: exercise.name, sets: records[index] || [] })).filter((item) => item.sets.length);
    if (completed.length) setWorkoutHistory((items) => [{ id: `session-${Date.now()}`, date: now.toISOString().slice(0, 10), time: now.toLocaleTimeString("zh-CN", { hour: "2-digit", minute: "2-digit", hour12: false }), title: activePlanName || "自由训练", duration: Math.max(1, Math.round((Date.now() - (workoutStartedAt || Date.now())) / 60000)), volume: completed.reduce((sum, item) => sum + item.sets.reduce((setSum, set) => setSum + set.reps * set.weight, 0), 0), exercises: completed }, ...items]);
    setWorkoutMode("sessionDone");
  }
  function downloadFile(name: string, content: string, type: string) {
    const url = URL.createObjectURL(new Blob([content], { type }));
    const link = document.createElement("a"); link.href = url; link.download = name; link.click(); URL.revokeObjectURL(url);
  }
  function exportBackup() { downloadFile(`个人工作台备份-${new Date().toISOString().slice(0,10)}.json`, JSON.stringify({ version: 3, exportedAt: new Date().toISOString(), transactions, tasks, backup, exerciseLibrary, trainingPlans, workoutHistory, bankAccounts, incomeCategories }, null, 2), "application/json"); notify("完整备份已导出"); }
  function exportCsv() {
    const rows = [["类型","金额","分类","商户","支付平台","时间"], ...transactions.map((item) => [item.type, item.amount, item.category, item.merchant || "", item.platform || "", item.time])];
    downloadFile(`账目-${new Date().toISOString().slice(0,10)}.csv`, `\ufeff${rows.map((row) => row.map((cell) => `"${String(cell).replaceAll('"','""')}"`).join(",")).join("\n")}`, "text/csv;charset=utf-8"); notify("账目 CSV 已导出");
  }
  function importBackup(file: File) {
    file.text().then((text) => { const data = JSON.parse(text); if (Array.isArray(data.transactions) && Array.isArray(data.tasks)) { setTransactions(data.transactions); setTasks(data.tasks); if (Array.isArray(data.exerciseLibrary)) setExerciseLibrary(data.exerciseLibrary); if (Array.isArray(data.trainingPlans)) setTrainingPlans(data.trainingPlans); if (Array.isArray(data.workoutHistory)) setWorkoutHistory(data.workoutHistory); if (Array.isArray(data.bankAccounts)) setBankAccounts(data.bankAccounts); if (Array.isArray(data.incomeCategories) && data.incomeCategories.length) setIncomeCategories(data.incomeCategories); if (typeof data.backup === "boolean") setBackup(data.backup); notify("备份已恢复"); } }).catch(() => notify("无法读取这个备份文件"));
  }
  function restoreSnapshot(data: { transactions?: Transaction[]; tasks?: Task[]; backup?: boolean; exerciseLibrary?: Exercise[]; trainingPlans?: TrainingPlan[]; workoutHistory?: WorkoutSession[]; bankAccounts?: string[]; incomeCategories?: string[] }) { if (data.transactions) setTransactions(data.transactions); if (data.tasks) setTasks(data.tasks); if (data.exerciseLibrary) setExerciseLibrary(data.exerciseLibrary); if (data.trainingPlans) setTrainingPlans(data.trainingPlans); if (data.workoutHistory) setWorkoutHistory(data.workoutHistory); if (data.bankAccounts) setBankAccounts(data.bankAccounts); if (data.incomeCategories?.length) setIncomeCategories(data.incomeCategories); if (typeof data.backup === "boolean") setBackup(data.backup); notify("已恢复本地快照"); }

  const renderContent = () => {
    if (active === "记账") return <FinancePage spentToday={spentToday} transactions={transactions} onAdd={() => setTransactionOpen(true)} onShortcut={() => setShortcutOpen(true)} />;
    if (active === "运动") return <WorkoutPage mode={workoutMode} exercises={workoutExercises} exerciseIndex={exerciseIndex} records={records} library={exerciseLibrary} plans={trainingPlans} sessions={workoutHistory} onCreateExercise={(item) => setExerciseLibrary((items) => [...items, item])} onSavePlan={(plan) => setTrainingPlans((items) => [...items, plan])} onStart={startWorkout} onCompleteSet={openSetConfirmation} onContinue={() => setWorkoutMode("active")} onChoose={() => setWorkoutMode("chooseAction")} onSelect={chooseExercise} onAddLibrary={addLibraryExercise} onCustom={() => setCustomOpen(true)} onFinish={finishWorkout} onBack={() => setWorkoutMode("decision")} />;
    if (active === "待办") return <TasksPage tasks={filteredTasks} filter={taskFilter} onFilter={setTaskFilter} onToggle={(id) => setTasks((items) => items.map((task) => task.id === id ? { ...task, done: !task.done } : task))} onAdd={openNewTask} onEdit={editTask} onDelete={(id) => { setTasks((items) => items.filter((task) => task.id !== id)); notify("待办已删除"); }} />;
    if (active === "同步") return <SyncPage backup={backup} onBackup={setBackup} syncing={syncing} onSync={() => notify("请先完成两台设备的安装，设备配对将在下一阶段启用")} onExport={exportBackup} onCsv={exportCsv} onImport={importBackup} onRestore={restoreSnapshot} />;
    return <Dashboard spentToday={spentToday} pendingTasks={pendingTasks} tasks={tasks} transactions={transactions} onNavigate={setActive} />;
  };

  return (
    <main className="app-shell">
      <aside className="sidebar">
        <div className="brand"><span className="brand-mark">工</span><span>个人工作台</span></div>
        <nav aria-label="主导航">{nav.map((item) => <button key={item.label} className={active === item.label ? "nav-item active" : "nav-item"} onClick={() => setActive(item.label)}><span className="nav-symbol">{item.mark}</span>{item.label}</button>)}</nav>
        <div className="privacy-badge"><span>✓</span><div><strong>仅本地存储</strong><small>设备数据不会上传</small></div></div>
      </aside>
      <section className="content"><header className="topbar"><div><p>{new Date().toLocaleDateString("zh-CN", { month: "long", day: "numeric", weekday: "long" })}</p><h1>{active === "总览" ? "今天" : active}</h1></div><button className="sync-pill" onClick={() => setActive("同步")}><span>✓</span> 已同步</button></header>{renderContent()}</section>
      <nav className="bottom-nav" aria-label="移动端导航">{nav.map((item) => <button key={item.label} className={active === item.label ? "active" : ""} onClick={() => setActive(item.label)}><span className="mobile-icon">{item.mark}</span>{item.label}</button>)}</nav>

      {transactionOpen && <Modal title="快速记账" onClose={() => setTransactionOpen(false)}>
        <div className="segmented"><button className={transactionType === "支出" ? "selected" : ""} onClick={() => { setTransactionType("支出"); setCategory("餐饮"); if (paymentPlatform === "银行卡") setPaymentPlatform("微信支付"); }}>支出</button><button className={transactionType === "收入" ? "selected" : ""} onClick={() => { setTransactionType("收入"); setCategory(incomeCategories[0] || "正常收入"); }}>收入</button></div>
        <label className="field"><span>金额</span><div className="money-input"><b>¥</b><input inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value)} autoFocus /></div></label>
        {transactionType === "支出" && <label className="field"><span>商户（识别后可修改）</span><input className="text-input" value={merchant} onChange={(e) => setMerchant(e.target.value)} placeholder="例如：学校食堂" /></label>}
        <div className="field"><span>{transactionType === "收入" ? "收入平台" : "支付平台"}</span><div className="payment-platforms">{(transactionType === "收入" ? ["微信支付", "支付宝", "抖音支付", "美团支付", "银行卡", "其他平台"] : ["微信支付", "支付宝", "抖音支付", "美团支付", "其他支付"]).map((item) => <button key={item} className={paymentPlatform === item ? "selected" : ""} onClick={() => setPaymentPlatform(item)}>{item}</button>)}</div></div>
        {transactionType === "收入" && paymentPlatform === "银行卡" && <div className="field account-manager"><span>选择或管理银行卡</span>{bankAccounts.length > 0 && <div className="saved-options">{bankAccounts.map((item, index) => <div className={selectedBankAccount === item ? "selected" : ""} key={index}><button className="option-select" onClick={() => setSelectedBankAccount(item)}>✓</button><input value={item} onChange={(event) => renameBankAccount(index, event.target.value)} aria-label={`银行卡 ${index + 1}`} /><button className="option-delete" onClick={() => deleteBankAccount(index)} aria-label={`删除 ${item}`}>删除</button></div>)}</div>}<div className="add-option"><input className="text-input" value={newBankAccount} onChange={(event) => setNewBankAccount(event.target.value)} placeholder="例如：招商银行工资卡 1234" /><button onClick={addBankAccount}>＋ 添加</button></div></div>}
        {transactionType === "支出" ? <div className="field"><span>支出分类</span><div className="category-grid">{["餐饮", "交通", "购物", "娱乐", "其他"].map((item) => <button key={item} className={category === item ? "selected" : ""} onClick={() => setCategory(item)}>{item}</button>)}</div></div> : <div className="field income-category-manager"><span>收入分类</span><div className="income-category-pills">{incomeCategories.map((item, index) => <button key={index} className={category === item ? "selected" : ""} onClick={() => setCategory(item)}>{item || "未命名"}</button>)}</div><div className="saved-options">{incomeCategories.map((item, index) => <div key={index}><span className="option-dot"/><input value={item} onChange={(event) => renameIncomeCategory(index, event.target.value)} aria-label={`收入分类 ${index + 1}`} /><button className="option-delete" onClick={() => deleteIncomeCategory(index)} disabled={incomeCategories.length === 1}>删除</button></div>)}</div><div className="add-option"><input className="text-input" value={newIncomeCategory} onChange={(event) => setNewIncomeCategory(event.target.value)} placeholder="新分类名称" /><button onClick={addIncomeCategory}>＋ 添加</button></div></div>}
        <button className="primary blue-button" onClick={addTransaction}>保存记录</button>
      </Modal>}
      {shortcutOpen && <Modal title="设置双击背面记账" onClose={() => setShortcutOpen(false)}>
        <div className="shortcut-guide"><p>快捷指令只把付款截图识别出的文字放在网址 <b>#</b> 后面；这些文字不会发送给网站服务器。</p><ol><li>在“快捷指令”中新建“付款后记账”。</li><li>依次加入：截取屏幕、从图像提取文本、URL 编码。</li><li>拼接下方地址与编码后的文本，再使用“打开 URL”。</li><li>进入“设置 → 辅助功能 → 触控 → 轻点背面 → 轻点两下”，选择该快捷指令。</li></ol><div className="shortcut-url"><code>{shortcutUrl}</code><button onClick={() => { navigator.clipboard?.writeText(shortcutUrl); notify("快捷指令地址已复制"); }}>复制地址</button></div><small>设置完成后，在微信、支付宝、抖音或美团付款成功页轻点背面两下，即会进入确认页。</small></div>
      </Modal>}
      {taskOpen && <Modal title={editingTaskId !== null ? "修改待办" : "新建待办"} onClose={() => { setTaskOpen(false); setEditingTaskId(null); }}>
        <label className="field"><span>事项</span><input className="text-input" value={taskTitle} onChange={(e) => setTaskTitle(e.target.value)} placeholder="准备做什么？" autoFocus /></label>
        <div className="field"><span>分类</span><div className="category-grid compact">{["日常", "采购", "杂事", "课题"].map((item) => <button key={item} className={taskCategory === item ? "selected purple-selected" : ""} onClick={() => setTaskCategory(item)}>{item}</button>)}</div></div>
        <label className="field"><span>截止时间（必填）</span><input className="text-input" type="datetime-local" value={deadline} onChange={(e) => setDeadline(e.target.value)} /></label>
        <div className="field"><span>优先级（可选）</span><div className="category-grid compact">{["无", "低", "中", "高"].map((item) => <button key={item} className={taskPriority === item ? "selected purple-selected" : ""} onClick={() => setTaskPriority(item)}>{item}</button>)}</div></div>
        <button className="primary purple-button" onClick={saveTask}>{editingTaskId !== null ? "保存修改" : "创建待办"}</button>
      </Modal>}
      {workoutMode === "confirm" && <Modal title="确认本组" onClose={() => setWorkoutMode("active")}>
        <Stepper label="实际次数" value={actualReps} unit="次" step={1} onChange={setActualReps} />
        <Stepper label="实际重量" value={actualWeight} unit="kg" step={2.5} onChange={setActualWeight} />
        <button className="primary green-button" onClick={saveSet}>保存本组</button>
      </Modal>}
      {customOpen && <Modal title="自定义动作" onClose={() => setCustomOpen(false)}>
        <label className="field"><span>动作名称（必填）</span><input className="text-input" value={customName} onChange={(e) => setCustomName(e.target.value)} placeholder="例如：保加利亚分腿蹲" autoFocus /></label>
        <label className="field"><span>计划组数</span><input className="text-input" inputMode="numeric" value={customSets} onChange={(e) => setCustomSets(e.target.value)} /></label>
        <div className="custom-fields"><label className="field"><span>每组次数（可留空）</span><input className="text-input" inputMode="numeric" value={customReps} onChange={(e) => setCustomReps(e.target.value)} placeholder="留空" /></label><label className="field"><span>重量 kg（可留空）</span><input className="text-input" inputMode="decimal" value={customWeight} onChange={(e) => setCustomWeight(e.target.value)} placeholder="留空" /></label></div>
        <button className="primary green-button" onClick={addCustomExercise}>加入并开始此动作</button>
      </Modal>}
      {toast && <div className="toast" role="status">✓ {toast}</div>}
    </main>
  );
}

function Dashboard({ spentToday, pendingTasks, tasks, transactions, onNavigate }: { spentToday: number; pendingTasks: number; tasks: Task[]; transactions: Transaction[]; onNavigate: (tab: Tab) => void }) {
  return <>
    <div className="stat-grid">
      <button className="stat-card finance" onClick={() => onNavigate("记账")}><span>今日开销</span><strong>¥{spentToday.toFixed(2)}</strong><small>{transactions.length ? "查看今日流水" : "还没有记账记录"}</small></button>
      <button className="stat-card workout" onClick={() => onNavigate("运动")}><span>今日运动</span><strong>0<em>分钟</em></strong><small>尚未开始训练</small></button>
      <button className="stat-card tasks" onClick={() => onNavigate("待办")}><span>待办事项</span><strong>{pendingTasks}<em>项</em></strong><small>{pendingTasks ? "查看待完成事项" : "暂无待办"}</small></button>
    </div>
    <div className="dashboard-grid">
      <article className="panel"><div className="panel-heading"><div><small>即将截止</small><h2>今天要完成</h2></div><button onClick={() => onNavigate("待办")}>查看全部</button></div>{tasks.filter((t) => !t.done).slice(0, 4).map((task) => <div className="task-row" key={task.id}><span className={`check ${task.category === "采购" ? "orange" : task.category === "日常" ? "purple" : "blue"}`} /><div><strong>{task.title}</strong><small>{task.category}</small></div><time>{task.deadline}</time></div>)}{!tasks.some((task) => !task.done) && <EmptyState title="暂无待办" text="新建的待办会显示在这里" />}</article>
      <article className="panel recent"><div className="panel-heading"><div><small>最近动态</small><h2>记录时间线</h2></div></div>{transactions.slice(0, 4).map((item) => <div className="activity" key={item.id}><b className="a-finance">¥</b><div><strong>{item.category}{item.type} ¥{item.amount.toFixed(2)}</strong><small>{item.time}</small></div></div>)}{!transactions.length && <EmptyState title="暂无记录" text="记账、训练等动态会显示在这里" />}</article>
    </div>
  </>;
}

function FinancePage({ transactions, onAdd, onShortcut }: { spentToday: number; transactions: Transaction[]; onAdd: () => void; onShortcut: () => void }) {
  const [range, setRange] = useState<"日" | "月" | "年">("月");
  const [offset, setOffset] = useState(0);
  const selectedDate = useMemo(() => { const date = new Date(); if (range === "日") date.setDate(date.getDate() + offset); if (range === "月") date.setMonth(date.getMonth() + offset); if (range === "年") date.setFullYear(date.getFullYear() + offset); return date; }, [range, offset]);
  const periodLabel = range === "日" ? selectedDate.toLocaleDateString("zh-CN", { year: "numeric", month: "long", day: "numeric" }) : range === "月" ? selectedDate.toLocaleDateString("zh-CN", { year: "numeric", month: "long" }) : `${selectedDate.getFullYear()} 年`;
  const inPeriod = (item: Transaction) => { const date = new Date(item.createdAt || item.id); if (Number.isNaN(date.getTime())) return false; if (range === "日") return date.toDateString() === selectedDate.toDateString(); if (range === "月") return date.getFullYear() === selectedDate.getFullYear() && date.getMonth() === selectedDate.getMonth(); return date.getFullYear() === selectedDate.getFullYear(); };
  const visible = transactions.filter(inPeriod);
  const income = visible.filter((item) => item.type === "收入").reduce((sum, item) => sum + item.amount, 0);
  const expense = visible.filter((item) => item.type === "支出").reduce((sum, item) => sum + item.amount, 0);
  const categories = Array.from(visible.filter((item) => item.type === "支出").reduce((map, item) => map.set(item.category, (map.get(item.category) || 0) + item.amount), new Map<string, number>()).entries()).sort((a, b) => b[1] - a[1]);
  const slots = range === "日" ? ["0时", "4时", "8时", "12时", "16时", "20时"] : range === "月" ? ["1周", "2周", "3周", "4周", "5周"] : ["1月", "3月", "5月", "7月", "9月", "11月"];
  const values = slots.map((_, index) => visible.filter((item) => { const date = new Date(item.createdAt || item.id); return range === "日" ? Math.floor(date.getHours() / 4) === index : range === "月" ? Math.min(4, Math.floor((date.getDate() - 1) / 7)) === index : Math.floor(date.getMonth() / 2) === index; }).reduce((sum, item) => sum + (item.type === "支出" ? item.amount : 0), 0));
  const maxValue = Math.max(1, ...values);
  return <div className="page-stack">
    <div className="page-actions"><div><div className="range-tabs">{(["日", "月", "年"] as const).map((item) => <button key={item} className={range === item ? "selected" : ""} onClick={() => { setRange(item); setOffset(0); }}>{item}</button>)}</div><div className="period-nav"><button onClick={() => setOffset((value) => value - 1)}>‹</button><strong>{periodLabel}</strong><button onClick={() => setOffset((value) => value + 1)} disabled={offset >= 0}>›</button></div></div><div className="finance-actions"><button className="shortcut-entry" onClick={onShortcut}>轻点背面记账设置</button><button className="primary blue-button small-primary" onClick={onAdd}>＋ 记一笔</button></div></div>
    <div className="summary-grid"><article className="summary-card blue-tint"><small>本{range}收入</small><strong>¥{income.toFixed(2)}</strong></article><article className="summary-card"><small>本{range}支出</small><strong>¥{expense.toFixed(2)}</strong></article><article className="summary-card"><small>结余</small><strong>¥{(income - expense).toFixed(2)}</strong></article><article className="summary-card"><small>记录数</small><strong>{visible.length} 笔</strong></article></div>
    <div className="analytics-grid"><article className="panel chart-panel"><div className="panel-heading"><div><small>分类占比</small><h2>{periodLabel}支出</h2></div></div>{categories.length ? <div className="donut-wrap"><div className="donut dynamic-donut"><span>¥{expense.toFixed(0)}</span></div><div className="legend">{categories.map(([name, value], index) => <p key={name}><i className={`l${index % 4 + 1}`}/>{name} <b>{Math.round(value / expense * 100)}%</b></p>)}</div></div> : <EmptyState title="暂无分类数据" text="本周期还没有支出记录" />}</article><article className="panel chart-panel"><div className="panel-heading"><div><small>支出趋势</small><h2>{periodLabel}</h2></div></div>{expense ? <div className="bar-chart">{values.map((value, index) => <div key={slots[index]}><span style={{ height: `${Math.max(4, value / maxValue * 100)}%` }}/><small>{slots[index]}</small></div>)}</div> : <EmptyState title="暂无趋势数据" text="添加记录后自动生成趋势" />}</article></div>
    <article className="panel transaction-list"><div className="panel-heading"><div><small>{periodLabel}</small><h2>流水记录</h2></div><span>{visible.length} 笔</span></div>{visible.map((item) => <div className="transaction-row" key={item.id}><span className="transaction-icon">{item.category.slice(0,1)}</span><div><strong>{item.merchant || item.category}</strong><small>{item.category} · {item.platform || "手动记录"} · {item.time}</small></div><b className={item.type === "收入" ? "income" : ""}>{item.type === "收入" ? "+" : "−"}¥{item.amount.toFixed(2)}</b></div>)}{!visible.length && <EmptyState title="本周期没有流水" text="可切换周期或新记一笔" />}</article>
  </div>;
}

function WorkoutPage({ mode, exercises, exerciseIndex, records, library, plans, sessions, onCreateExercise, onSavePlan, onStart, onCompleteSet, onContinue, onChoose, onSelect, onAddLibrary, onCustom, onFinish, onBack }: { mode: string; exercises: Exercise[]; exerciseIndex: number; records: SetRecord[][]; library: Exercise[]; plans: TrainingPlan[]; sessions: WorkoutSession[]; onCreateExercise: (exercise: Exercise) => void; onSavePlan: (plan: TrainingPlan) => void; onStart: (plan?: TrainingPlan) => void; onCompleteSet: () => void; onContinue: () => void; onChoose: () => void; onSelect: (index: number) => void; onAddLibrary: (exercise: Exercise) => void; onCustom: () => void; onFinish: () => void; onBack: () => void }) {
  const [section, setSection] = useState<"start" | "calendar" | "library" | "plans">("start");
  const exercise = exercises[exerciseIndex]; const sets = records[exerciseIndex] || [];
  const planText = (item: Exercise) => `${item.sets} 组${item.reps === null ? "" : ` × ${item.reps} 次`}${item.weight === null ? "" : ` × ${item.weight} kg`}`;
  const sectionNav = <div className="workout-subnav">{[["start","开始训练"],["calendar","训练日历"],["library","动作库"],["plans","训练计划"]].map(([key,label]) => <button key={key} className={section === key ? "active" : ""} onClick={() => setSection(key as typeof section)}>{label}</button>)}</div>;
  if (mode === "chooseAction") return <div className="action-picker">
    <div className="picker-heading"><button onClick={onBack}>‹</button><div><small>当前动作进度已保留</small><h2>选择下一个动作</h2></div><button className="custom-action-button" onClick={onCustom}>＋ 自定义</button></div>
    <article className="panel"><div className="panel-heading"><div><small>随时返回未完成动作</small><h2>本次训练</h2></div></div><div className="session-exercises">{exercises.map((item, index) => { const completed = records[index]?.length || 0; return <button key={item.id} className={index === exerciseIndex ? "current" : ""} onClick={() => onSelect(index)}><span className="library-icon">{item.name.slice(0,1)}</span><div><strong>{item.name}</strong><small>{planText(item)}</small></div><em>{completed}/{item.sets} 组</em><i>{index === exerciseIndex ? "当前" : "选择"}</i></button>; })}</div></article>
    <article className="panel"><div className="panel-heading"><div><small>选择后加入本次训练</small><h2>动作库</h2></div><button>全部动作</button></div><div className="library-grid">{library.map((item) => <button key={item.id} onClick={() => onAddLibrary(item)}><span className="library-icon">{item.name.slice(0,1)}</span><div><strong>{item.name}</strong><small>{item.group} · {planText(item)}</small></div><b>＋</b></button>)}</div></article>
  </div>;
  if (mode === "active" || mode === "confirm" || mode === "decision") return <div className="active-workout">
    <div className="workout-banner"><div><small>进行中的训练</small><h2>{exercise.name}</h2><div className="workout-badges"><span>动作 {exerciseIndex + 1}/{exercises.length}</span><span>{sets.length >= exercise.sets ? `加练第 ${sets.length + 1} 组` : `第 ${sets.length + 1}/${exercise.sets} 组`}</span></div></div><b>{exercise.weight ?? "—"}<small>{exercise.weight === null ? "自由" : "kg"}</small></b></div>
    {mode === "decision" ? <><article className="panel completed-sets"><h3>第 {sets.length} 组已保存</h3>{sets.map((set, i) => <div key={i}><span>第 {i + 1} 组</span><b>{set.reps || "—"} 次</b><b>{set.weight || "—"} kg</b><i>✓</i></div>)}</article><article className="post-set-actions"><small>接下来做什么？</small><button className="primary green-button" onClick={onContinue}>继续下一组</button><button className="action-option" onClick={onChoose}><b>选择下一个动作</b><span>可返回未完成动作</span></button><button className="action-option danger" onClick={onFinish}><b>结束训练</b><span>保存本次训练记录</span></button></article></> : <><article className="panel planned-set"><small>本组计划</small><div><strong>{exercise.reps ?? "—"}<em>{exercise.reps === null ? "自由" : "次"}</em></strong><strong>{exercise.weight ?? "—"}<em>{exercise.weight === null ? "自由" : "kg"}</em></strong></div></article>{sets.length > 0 && <article className="panel completed-sets"><h3>已完成</h3>{sets.map((set, i) => <div key={i}><span>第 {i + 1} 组</span><b>{set.reps || "—"} 次</b><b>{set.weight || "—"} kg</b><i>✓</i></div>)}</article>}<article className="panel upcoming"><h3>本次训练进度</h3>{exercises.filter((_, index) => index !== exerciseIndex).map((item) => { const index = exercises.findIndex((entry) => entry.id === item.id); return <button key={item.id} onClick={() => onSelect(index)}><strong>{item.name}</strong><span>{records[index]?.length || 0}/{item.sets} 组 · 点击切换</span></button>; })}</article><button className="primary green-button workout-cta" onClick={onCompleteSet}>完成本组</button></>}
  </div>;
  if (mode === "sessionDone") { const total = records.reduce((sum, group) => sum + group.length, 0); return <div className="success-state"><div className="success-check">✓</div><h2>训练已保存</h2><p>本次完成 {exercises.filter((_, i) => records[i]?.length).length} 个动作 · 共 {total} 组</p><div className="session-summary">{exercises.filter((_, i) => records[i]?.length).map((item) => <span key={item.id}>{item.name}<b>{records[exercises.indexOf(item)]?.length} 组</b></span>)}</div><button className="primary green-button" onClick={() => onStart()}>开始新的训练</button></div>; }
  if (section === "calendar") return <>{sectionNav}<WorkoutCalendar sessions={sessions} /></>;
  if (section === "library") return <>{sectionNav}<WorkoutLibrary exercises={library} sessions={sessions} onCreate={onCreateExercise} /></>;
  if (section === "plans") return <>{sectionNav}<WorkoutPlans exercises={library} plans={plans} onSave={onSavePlan} onStart={onStart} /></>;
  if (!plans.length) return <>{sectionNav}<div className="panel workout-onboarding"><span>1</span><h2>先建立你的训练内容</h2><p>动作库和训练计划已经清空。请先创建动作，再把动作加入训练计划。</p><div><button className="primary green-button" onClick={() => setSection("library")}>创建第一个动作</button><button className="action-option" onClick={() => setSection("plans")}>制定训练计划</button></div></div></>;
  const plan = plans[0]; const plannedExercises = plan.actions.map((name) => library.find((item) => item.name === name)).filter((item): item is Exercise => Boolean(item));
  return <>{sectionNav}<div className="page-stack"><article className="hero-plan"><div><small>当前计划</small><h2>{plan.name}</h2><p>{plannedExercises.length} 个动作 · {plannedExercises.reduce((sum, item) => sum + item.sets, 0)} 组</p><button onClick={() => onStart(plan)}>开始训练</button></div><div className="weight-orb">{plannedExercises.length}<small>项</small><span>训练动作</span></div></article><article className="panel"><div className="panel-heading"><div><small>今日训练</small><h2>动作计划</h2></div><button onClick={() => setSection("plans")}>切换计划</button></div>{plannedExercises.map((item, i) => <div className="exercise-row" key={item.id}><span>{i + 1}</span><div><strong>{item.name}</strong><small>{planText(item)}</small></div><b>{item.weight === null ? "自由" : `${item.weight} kg`}</b></div>)}</article></div></>;
}

function WorkoutCalendar({ sessions }: { sessions: WorkoutSession[] }) {
  const now = new Date(); const year = now.getFullYear(); const month = now.getMonth(); const monthPrefix = `${year}-${String(month + 1).padStart(2, "0")}`;
  const [selectedDate, setSelectedDate] = useState(`${monthPrefix}-${String(now.getDate()).padStart(2, "0")}`);
  const [selectedSessionId, setSelectedSessionId] = useState<string | null>(null);
  const selectedSessions = sessions.filter((session) => session.date === selectedDate);
  const selectedSession = sessions.find((session) => session.id === selectedSessionId);
  const firstDay = new Date(year, month, 1).getDay(); const dayCount = new Date(year, month + 1, 0).getDate();
  const days = Array.from({ length: firstDay + dayCount }, (_, index) => index < firstDay ? null : index - firstDay + 1);
  const monthSessions = sessions.filter((session) => session.date.startsWith(monthPrefix));
  const sessionDays = new Set(monthSessions.map((session) => Number(session.date.slice(-2))));
  const totalMinutes = monthSessions.reduce((sum, session) => sum + session.duration, 0); const totalVolume = monthSessions.reduce((sum, session) => sum + session.volume, 0);

  if (selectedSession) return <div className="session-detail page-stack">
    <button className="detail-back" onClick={() => setSelectedSessionId(null)}>‹ 返回 {Number(selectedSession.date.slice(-2))} 日训练场次</button>
    <article className="session-detail-hero"><div><small>{new Date(selectedSession.date).toLocaleDateString("zh-CN")} · {selectedSession.time}</small><h2>{selectedSession.title}</h2><p>{selectedSession.duration} 分钟 · {selectedSession.exercises.length} 个动作 · 总容量 {selectedSession.volume.toLocaleString()} kg</p></div><b>已完成<span>✓</span></b></article>
    <div className="session-detail-list">{selectedSession.exercises.map((exercise, index) => <article className="panel session-exercise-detail" key={`${exercise.name}-${index}`}><div className="panel-heading"><div><small>动作 {index + 1}</small><h2>{exercise.name}</h2></div><b>{exercise.sets.length} 组</b></div>{exercise.sets.map((set, setIndex) => <div className="set-line" key={setIndex}><span>第 {setIndex + 1} 组</span><strong>{set.reps || "—"} 次</strong><b>{set.weight || "—"} kg</b></div>)}</article>)}</div>
  </div>;

  return <div className="page-stack workout-history-page">
    <div className="history-stats"><article><small>本月训练</small><strong>{monthSessions.length}<em>场</em></strong></article><article><small>累计时长</small><strong>{totalMinutes}<em>分钟</em></strong></article><article><small>训练容量</small><strong>{totalVolume.toLocaleString()}<em>kg</em></strong></article></div>
    <div className="calendar-layout">
      <article className="panel training-calendar"><div className="calendar-toolbar"><span/><div><small>完整训练记录</small><h2>{year} 年 {month + 1} 月</h2></div><span/></div><div className="calendar-weekdays">{["日","一","二","三","四","五","六"].map((day) => <span key={day}>{day}</span>)}</div><div className="training-days">{days.map((day, index) => day ? <button key={day} className={`${sessionDays.has(day) ? "has-session" : ""} ${selectedDate === `${monthPrefix}-${String(day).padStart(2,"0")}` ? "selected-day" : ""}`} onClick={() => { setSelectedDate(`${monthPrefix}-${String(day).padStart(2,"0")}`); setSelectedSessionId(null); }}><span>{day}</span>{sessionDays.has(day) && <i>{monthSessions.filter((session) => Number(session.date.slice(-2)) === day).length}</i>}</button> : <span key={`blank-${index}`} />)}</div><p className="calendar-legend"><i />有训练记录 · 圆点数字表示当天场次数</p></article>
      <article className="panel session-list"><div className="panel-heading"><div><small>先选择场次，再查看动作明细</small><h2>{month + 1} 月 {Number(selectedDate.slice(-2))} 日</h2></div><span>{selectedSessions.length} 场</span></div>{selectedSessions.length ? selectedSessions.map((session) => <button className="session-card" key={session.id} onClick={() => setSelectedSessionId(session.id)}><time>{session.time}</time><div><strong>{session.title}</strong><small>{session.duration} 分钟 · {session.exercises.length} 个动作</small></div><b>{session.volume ? `${session.volume.toLocaleString()} kg` : "有氧"}</b><i>›</i></button>) : <div className="empty-training-day"><span>休</span><h3>当天没有训练</h3><p>点击日历中带圆点的日期查看记录</p></div>}</article>
    </div>
  </div>;
}

function WorkoutLibrary({ exercises, sessions, onCreate }: { exercises: Exercise[]; sessions: WorkoutSession[]; onCreate: (exercise: Exercise) => void }) {
  const uniqueExercises = Array.from(new Map(exercises.map((item) => [item.id, item])).values());
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [open, setOpen] = useState(false);
  const [name, setName] = useState(""); const [group, setGroup] = useState("自定义"); const [sets, setSets] = useState("4"); const [reps, setReps] = useState(""); const [weight, setWeight] = useState("");
  const selected = uniqueExercises.find((item) => item.id === selectedId);
  const history = selected ? sessions.flatMap((session) => session.exercises.filter((item) => item.name === selected.name).map((item) => ({ date: session.date, time: session.time, sets: item.sets }))) : [];
  const maxWeight = history.flatMap((item) => item.sets).reduce((max, item) => Math.max(max, item.weight), 0);
  const totalSets = history.reduce((sum, item) => sum + item.sets.length, 0);

  if (selected) return <div className="action-detail page-stack">
    <button className="detail-back" onClick={() => setSelectedId(null)}>‹ 返回动作库</button>
    <article className="action-detail-hero"><span className="library-icon">{selected.name.slice(0,1)}</span><div><small>{selected.group}</small><h2>{selected.name}</h2><p>计划 {selected.sets} 组{selected.reps ? ` × ${selected.reps} 次` : ""}{selected.weight ? ` · ${selected.weight} kg` : ""}</p></div></article>
    <div className="action-stats"><article><small>历史训练</small><strong>{history.length}<em>次</em></strong></article><article><small>累计完成</small><strong>{totalSets}<em>组</em></strong></article><article><small>最高重量</small><strong>{maxWeight || "—"}<em>kg</em></strong></article></div>
    <article className="panel action-chart"><div className="panel-heading"><div><small>重量变化曲线</small><h2>每次训练最高重量</h2></div><b className="positive">{history.length > 1 ? `+${Math.max(0, maxWeight - Math.max(...history[history.length - 1].sets.map((set) => set.weight)))} kg` : "持续记录"}</b></div><div className="weight-bars">{history.slice().reverse().map((item) => { const value = Math.max(...item.sets.map((set) => set.weight)); return <div key={item.date}><b style={{ height: `${value ? Math.max(18, value / Math.max(1, maxWeight) * 100) : 8}%` }} /><span>{item.date.slice(5).replace("-","/")}</span><small>{value || "—"}</small></div>; })}</div></article>
    <article className="panel action-history"><div className="panel-heading"><div><small>完整训练记录</small><h2>历史组数、次数与重量</h2></div></div>{history.length ? history.map((entry) => <section key={`${entry.date}-${entry.time}`}><header><strong>{new Date(entry.date).toLocaleDateString("zh-CN")}</strong><span>{entry.time} · {entry.sets.length} 组</span></header>{entry.sets.map((set, index) => <div className="set-line" key={index}><span>第 {index + 1} 组</span><strong>{set.reps || "—"} 次</strong><b>{set.weight || "—"} kg</b></div>)}</section>) : <div className="empty-training-day"><h3>还没有历史记录</h3><p>完成包含此动作的训练后会自动显示在这里</p></div>}</article>
  </div>;

  function createExercise() { if (!name.trim()) return; onCreate({ id: `exercise-${Date.now()}`, name: name.trim(), group: group.trim() || "自定义", sets: Math.max(1, Number(sets) || 1), reps: reps === "" ? null : Number(reps), weight: weight === "" ? null : Number(weight) }); setName(""); setReps(""); setWeight(""); setOpen(false); }
  return <div className="page-stack action-library-page"><div className="section-intro"><div><small>统一管理训练动作</small><h2>动作库</h2><p>点击动作，查看该动作的历史组数、次数和重量变化。</p></div><button onClick={() => setOpen(true)}>＋ 新建动作</button></div>{uniqueExercises.length ? <div className="action-library-grid">{uniqueExercises.map((item) => { const count = sessions.reduce((sum, session) => sum + session.exercises.filter((exercise) => exercise.name === item.name).length, 0); return <button className="action-library-card" key={item.id} onClick={() => setSelectedId(item.id)}><span className="library-icon">{item.name.slice(0,1)}</span><div><small>{item.group}</small><strong>{item.name}</strong><p>{item.sets} 组{item.reps ? ` × ${item.reps} 次` : ""}{item.weight ? ` · ${item.weight} kg` : ""}</p></div><b>{count ? `${count} 次记录` : "暂无记录"}</b><i>›</i></button>; })}</div> : <div className="panel"><EmptyState title="动作库为空" text="创建动作后，才能制定训练计划" /></div>}{open && <Modal title="新建动作" onClose={() => setOpen(false)}><label className="field"><span>动作名称（必填）</span><input className="text-input" value={name} onChange={(event) => setName(event.target.value)} placeholder="例如：深蹲" autoFocus /></label><label className="field"><span>训练部位</span><input className="text-input" value={group} onChange={(event) => setGroup(event.target.value)} placeholder="例如：腿部" /></label><label className="field"><span>计划组数</span><input className="text-input" inputMode="numeric" value={sets} onChange={(event) => setSets(event.target.value)} /></label><div className="custom-fields"><label className="field"><span>每组次数（可选）</span><input className="text-input" inputMode="numeric" value={reps} onChange={(event) => setReps(event.target.value)} /></label><label className="field"><span>重量 kg（可选）</span><input className="text-input" inputMode="decimal" value={weight} onChange={(event) => setWeight(event.target.value)} /></label></div><button className="primary green-button" onClick={createExercise}>保存到动作库</button></Modal>}</div>;
}

function WorkoutPlans({ exercises, plans, onSave, onStart }: { exercises: Exercise[]; plans: TrainingPlan[]; onSave: (plan: TrainingPlan) => void; onStart: (plan: TrainingPlan) => void }) {
  const uniqueExercises = Array.from(new Map(exercises.map((item) => [item.id, item])).values());
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [chosen, setChosen] = useState<string[]>([]);
  function savePlan() { if (!name.trim() || !chosen.length) return; onSave({ id: `plan-${Date.now()}`, name: name.trim(), days: "未设置训练日", actions: chosen }); setName(""); setChosen([]); setOpen(false); }
  return <div className="page-stack plans-page"><div className="section-intro"><div><small>支持保存多套方案</small><h2>训练计划</h2><p>创建、调整训练计划，并随时选择其中一套开始训练。</p></div><button onClick={() => uniqueExercises.length && setOpen(true)} disabled={!uniqueExercises.length}>＋ 制定新计划</button></div>{plans.length ? <div className="plan-grid">{plans.map((plan, index) => <article className={`plan-card ${index === 0 ? "current-plan" : ""}`} key={plan.id}><header><span>{index === 0 ? "当前计划" : "已保存"}</span></header><h2>{plan.name}</h2><p>{plan.days} · {plan.actions.length} 个动作</p><div className="plan-actions">{plan.actions.map((action, actionIndex) => <span key={action}><i>{actionIndex + 1}</i>{action}</span>)}</div><button className="plan-start" onClick={() => onStart(plan)}>开始训练</button></article>)}</div> : <div className="panel"><EmptyState title={uniqueExercises.length ? "还没有训练计划" : "请先创建动作"} text={uniqueExercises.length ? "选择动作并保存你的第一套训练计划" : "动作库为空，暂时无法制定计划"} /></div>}{open && <Modal title="制定训练计划" onClose={() => setOpen(false)}><label className="field"><span>计划名称（必填）</span><input className="text-input" value={name} onChange={(event) => setName(event.target.value)} placeholder="例如：背部强化" autoFocus /></label><div className="field"><span>从动作库选择动作（至少 1 个）</span><div className="plan-checklist">{uniqueExercises.map((item) => <button key={item.id} className={chosen.includes(item.name) ? "selected" : ""} onClick={() => setChosen((items) => items.includes(item.name) ? items.filter((value) => value !== item.name) : [...items, item.name])}><span>{chosen.includes(item.name) ? "✓" : "+"}</span><div><strong>{item.name}</strong><small>{item.group}</small></div></button>)}</div></div><button className="primary green-button" onClick={savePlan}>保存训练计划</button></Modal>}</div>;
}

function SwipeTaskItem({ task, onToggle, onEdit, onDelete }: { task: Task; onToggle: () => void; onEdit: () => void; onDelete: () => void }) {
  const [open, setOpen] = useState(false);
  const [dragX, setDragX] = useState(0);
  const startX = useRef<number | null>(null);
  const startOffset = useRef(0);
  const suppressClick = useRef(false);
  const actionWidth = 142;
  function beginSwipe(event: React.PointerEvent<HTMLDivElement>) { if (event.pointerType === "mouse" && event.button !== 0) return; startX.current = event.clientX; startOffset.current = open ? actionWidth : 0; suppressClick.current = false; event.currentTarget.setPointerCapture?.(event.pointerId); }
  function moveSwipe(event: React.PointerEvent<HTMLDivElement>) { if (startX.current === null) return; const delta = event.clientX - startX.current; if (Math.abs(delta) > 6) suppressClick.current = true; setDragX(Math.max(0, Math.min(actionWidth, startOffset.current + delta))); }
  function endSwipe(event: React.PointerEvent<HTMLDivElement>) { if (startX.current === null) return; const finalX = Math.max(0, Math.min(actionWidth, startOffset.current + event.clientX - startX.current)); const shouldOpen = finalX > actionWidth * .42; setOpen(shouldOpen); setDragX(shouldOpen ? actionWidth : 0); startX.current = null; }
  return <div className="swipe-task">
    <div className="swipe-actions"><button className="edit" onClick={onEdit}>修改</button><button className="delete" onClick={onDelete}>删除</button></div>
    <div className={`swipe-content ${open ? "open" : ""}`} style={{ transform: `translateX(${dragX}px)` }} onPointerDown={beginSwipe} onPointerMove={moveSwipe} onPointerUp={endSwipe} onPointerCancel={endSwipe}><button className={task.done ? "task-item done" : "task-item"} onClick={(event) => { if (suppressClick.current) { event.preventDefault(); suppressClick.current = false; return; } onToggle(); }}><span className="task-check">{task.done ? "✓" : ""}</span><div><strong>{task.title}</strong><small>{task.category}</small></div><time>{task.deadline}</time>{task.priority && <em className={`priority ${task.priority === "高" ? "high" : ""}`}>{task.priority}</em>}</button><button className="task-more" onClick={() => { const next = !open; setOpen(next); setDragX(next ? actionWidth : 0); }} aria-label="显示修改和删除">•••</button></div>
  </div>;
}

function TasksPage({ tasks, filter, onFilter, onToggle, onAdd, onEdit, onDelete }: { tasks: Task[]; filter: string; onFilter: (f: string) => void; onToggle: (id: number) => void; onAdd: () => void; onEdit: (task: Task) => void; onDelete: (id: number) => void }) {
  const today = new Date(); const monthName = today.toLocaleDateString("zh-CN", { year: "numeric", month: "long" }); const firstDay = new Date(today.getFullYear(), today.getMonth(), 1).getDay(); const dayCount = new Date(today.getFullYear(), today.getMonth() + 1, 0).getDate(); const deadlineDays = new Set(tasks.map((task) => task.deadlineISO ? new Date(task.deadlineISO).getDate() : -1));
  return <div className="page-stack"><div className="page-actions"><div className="filter-tabs">{["全部", "日常", "采购", "杂事", "课题"].map((item) => <button key={item} className={filter === item ? "selected" : ""} onClick={() => onFilter(item)}>{item}</button>)}</div><button className="primary purple-button small-primary" onClick={onAdd}>＋ 新建待办</button></div><div className="tasks-layout"><article className="panel task-list"><div className="panel-heading"><div><small>向右滑动可修改或删除</small><h2>{filter === "全部" ? "全部事项" : filter}</h2></div><span className="task-count">{tasks.filter((t) => !t.done).length} 项未完成</span></div>{tasks.map((task) => <SwipeTaskItem key={task.id} task={task} onToggle={() => onToggle(task.id)} onEdit={() => onEdit(task)} onDelete={() => onDelete(task.id)} />)}{!tasks.length && <EmptyState title="暂无待办" text="点击右上角新建第一条事项" />}</article><aside className="panel calendar-panel"><div className="calendar-heading"><span/><strong>{monthName}</strong><span/></div><div className="weekdays">{["日","一","二","三","四","五","六"].map((d) => <span key={d}>{d}</span>)}</div><div className="days">{Array.from({ length: firstDay + dayCount }, (_, index) => index < firstDay ? "" : String(index - firstDay + 1)).map((day,index) => <span key={index} className={day === String(today.getDate()) ? "today" : deadlineDays.has(Number(day)) ? "marked" : ""}>{day}</span>)}</div>{tasks.length ? <div className="calendar-note"><b>截止日期</b><p>{tasks[0].title}</p><small>{tasks[0].deadline} · {tasks[0].category}</small></div> : <EmptyState title="日历为空" text="新建待办后显示截止日期" />}</aside></div></div>;
}

function SyncPage({ backup, onBackup, syncing, onSync, onExport, onCsv, onImport, onRestore }: { backup: boolean; onBackup: (v: boolean) => void; syncing: boolean; onSync: () => void; onExport: () => void; onCsv: () => void; onImport: (file: File) => void; onRestore: (data: { transactions?: Transaction[]; tasks?: Task[]; backup?: boolean; exerciseLibrary?: Exercise[]; trainingPlans?: TrainingPlan[]; workoutHistory?: WorkoutSession[]; bankAccounts?: string[]; incomeCategories?: string[] }) => void }) {
  const [snapshots, setSnapshots] = useState<{ createdAt: string; transactions?: Transaction[]; tasks?: Task[]; backup?: boolean; exerciseLibrary?: Exercise[]; trainingPlans?: TrainingPlan[]; workoutHistory?: WorkoutSession[]; bankAccounts?: string[]; incomeCategories?: string[] }[]>([]);
  useEffect(() => { try { setSnapshots(JSON.parse(localStorage.getItem("personal-workbench-backups") || "[]")); } catch { setSnapshots([]); } }, []);
  return <div className="sync-page"><article className="local-banner"><span>✓</span><div><h2>工作台数据仅保存在设备中</h2><p>服务器只帮助两台设备建立临时连接，不保存账目、训练或待办内容。</p></div></article><article className="panel pwa-install-card"><div><small>安装 PWA</small><h2>把工作台放到主屏幕</h2></div><div className="install-steps"><p><b>iPhone</b><span>Safari 分享 → 添加到主屏幕 → 打开为网页 App</span></p><p><b>Mac</b><span>Chrome 地址栏右侧安装图标 → 安装“个人工作台”</span></p></div><em>安装后支持离线打开</em></article><article className="panel device-panel"><div className="device"><span className="phone-shape"/><strong>iPhone 14 Pro</strong><small>iOS 18.3.1</small></div><div className="connection"><i/><b>✓</b><i/><small>{syncing ? "同步中…" : "等待设备配对"}</small></div><div className="device"><span className="mac-shape"/><strong>MacBook Pro</strong><small>Chrome · macOS 13</small></div></article><button className="primary cyan-button sync-now" disabled={syncing} onClick={onSync}>{syncing ? "正在同步…" : "设备配对将在下一阶段启用"}</button><div className="sync-grid"><article className="panel setting-card"><div><small>同步后在 Mac 保留最近 5 次</small><h2>{backup ? "自动备份已开启" : "自动备份已关闭"}</h2><p>每次数据变化都会先建立本地快照，最多保存 5 份。</p></div><button className={backup ? "toggle on" : "toggle"} onClick={() => onBackup(!backup)} aria-label="切换自动备份"><i/></button></article><article className="panel backup-stats"><div><small>本地快照</small><strong>{snapshots.length} / 5</strong></div><div><small>最近备份</small><strong>{snapshots[0] ? new Date(snapshots[0].createdAt).toLocaleString("zh-CN", { hour: "2-digit", minute: "2-digit" }) : "暂无"}</strong></div><div><small>存储位置</small><strong>本机</strong></div></article></div>{snapshots.length > 0 && <article className="panel snapshot-list"><div className="panel-heading"><div><small>最近 5 次</small><h2>本地备份快照</h2></div></div>{snapshots.map((item, index) => <button key={item.createdAt} onClick={() => onRestore(item)}><span>备份 {snapshots.length - index}</span><strong>{new Date(item.createdAt).toLocaleString("zh-CN")}</strong><i>恢复</i></button>)}</article>}<article className="panel export-panel"><div><small>数据导出</small><h2>随时取回自己的数据</h2></div><div><button onClick={onCsv}>导出账目 CSV</button><button onClick={onExport}>导出完整备份</button><label className="import-button">恢复备份<input type="file" accept="application/json,.json" onChange={(event) => { const file = event.target.files?.[0]; if (file) onImport(file); event.currentTarget.value = ""; }} /></label></div></article></div>;
}

function EmptyState({ title, text }: { title: string; text: string }) {
  return <div className="empty-state"><span>＋</span><strong>{title}</strong><small>{text}</small></div>;
}

function Modal({ title, onClose, children }: { title: string; onClose: () => void; children: React.ReactNode }) {
  return <div className="modal-backdrop" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}><section className="modal" role="dialog" aria-modal="true" aria-label={title}><div className="modal-heading"><h2>{title}</h2><button onClick={onClose} aria-label="关闭">×</button></div>{children}</section></div>;
}
function Stepper({ label, value, unit, step, onChange }: { label: string; value: number; unit: string; step: number; onChange: (v: number) => void }) {
  return <div className="stepper"><span>{label}</span><div><button onClick={() => onChange(Math.max(0, value - step))}>−</button><strong>{value} <em>{unit}</em></strong><button onClick={() => onChange(value + step)}>＋</button></div></div>;
}
