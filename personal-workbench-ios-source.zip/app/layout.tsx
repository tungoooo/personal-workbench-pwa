import type { Metadata } from "next";
import "./globals.css";
import PWARegistration from "./PWARegistration";

export const metadata: Metadata = {
  metadataBase: new URL("https://personal-workbench-lxt.liuxintung92.chatgpt.site"),
  title: "个人工作台",
  description: "离线可用、数据保存在设备中的记账、训练与待办工作台。",
  manifest: "/manifest.webmanifest",
  applicationName: "个人工作台",
  icons: {
    icon: [{ url: "/app-icon-192.png", sizes: "192x192", type: "image/png" }, { url: "/app-icon-512.png", sizes: "512x512", type: "image/png" }],
    apple: [{ url: "/apple-touch-icon.png", sizes: "180x180", type: "image/png" }],
  },
  appleWebApp: { capable: true, statusBarStyle: "default", title: "个人工作台" },
  openGraph: { title: "个人工作台", description: "运动、记账、待办的一体化本地工作台", images: ["/og.png"] },
  twitter: { card: "summary_large_image", title: "个人工作台", description: "运动、记账、待办的一体化本地工作台", images: ["/og.png"] },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="zh-CN"><body><PWARegistration />{children}</body></html>;
}
