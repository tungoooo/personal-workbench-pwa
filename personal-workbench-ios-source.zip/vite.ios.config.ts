import react from "@vitejs/plugin-react";
import { defineConfig } from "vite";

export default defineConfig({
  root: "github-pages",
  base: "./",
  publicDir: "../public",
  plugins: [react()],
  build: {
    outDir: "../ios-dist",
    emptyOutDir: true,
    assetsDir: "",
  },
});
