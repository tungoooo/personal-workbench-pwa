import react from "@vitejs/plugin-react";
import { defineConfig } from "vite";

export default defineConfig({
  root: "github-pages",
  base: "/personal-workbench-pwa/",
  publicDir: "../public",
  plugins: [react()],
  build: {
    outDir: "../github-dist",
    emptyOutDir: true,
    assetsDir: "",
  },
});
