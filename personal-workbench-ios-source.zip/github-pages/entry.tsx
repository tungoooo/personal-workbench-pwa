import { createRoot } from "react-dom/client";
import { App } from "@capacitor/app";
import Home from "../app/page";
import "../app/globals.css";

function openWorkbenchUrl(value?: string) {
  if (!value) return;
  try {
    const url = new URL(value);
    if (url.protocol !== "workbench:") return;
    const route = url.hostname || url.pathname.replace(/^\//, "");
    if (route !== "quick-pay") return;
    const raw = url.searchParams.get("raw") || "";
    window.location.hash = `quick-pay?raw=${encodeURIComponent(raw)}`;
  } catch {
    // Ignore malformed external links.
  }
}

void App.addListener("appUrlOpen", ({ url }) => openWorkbenchUrl(url));
void App.getLaunchUrl().then(({ url }) => openWorkbenchUrl(url));

createRoot(document.getElementById("root")!).render(<Home />);

if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register(`${import.meta.env.BASE_URL}sw.js`, { scope: import.meta.env.BASE_URL }).catch(() => undefined);
  });
}
