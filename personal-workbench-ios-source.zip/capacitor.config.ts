import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "io.github.tungoooo.personalworkbench",
  appName: "个人工作台",
  webDir: "ios-dist",
  ios: {
    contentInset: "automatic",
  },
};

export default config;
